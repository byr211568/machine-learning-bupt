# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 20:10:35 2021

@author: Glaci
"""
import torch

Epochs = 20             #训练轮次
Da_size = 100           #attention的权重维度
Iteration = 20          #Induction-迭代次数
Learning_rate = 0.001   #学习率
Batch_size = 32         #批处理大小
Hidden_dim = 10         #隐藏状态维数
test_size = 0.9         #测试集所占比例
Qnum = 10
word_to_vec = dict()
word_to_id = dict()
tag_to_id = dict()
tag = ['restaurant','music','search','weather','movie']
for t in tag:
    tag_to_id[t] = len(tag_to_id)


def get_vector(vecfile):
    '''
    read wordvec from file
    return dict word->vector
    vector shape 300
    word number 10895
    
    '''
    fin = open(vecfile, 'rb')
    i = 0
    global word_to_vec
    global word_to_id
    for lines in fin.readlines():
        lines = str(lines)
        if i > 0:
            vec = lines.strip('\t\n').split(' ')
            word = str(vec[0]).replace("b'",'') 
            vec = [float(v) for v in vec[1:-1]]
            word_to_vec[word] = vec            
            word_to_id[word] = i-1
        i += 1
    fin.close()