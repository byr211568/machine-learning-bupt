# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 19:50:10 2021

@author: Glaci
"""

from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader

from Dataset import MyDataset
import parameters

    
def load_data(file):
    '''
    load data put the file into two list
    sentence, label
    and return the max length of all sentences
    tips: the content of list is the word

    '''
    fin = open(file, 'r', encoding='utf-8')
    sentence = list()
    label = list()
    length = 0
    for lines in fin.readlines():
        line = lines.strip('\n').split('\t')
        label.append(line[0])
        sen = line[1].split(' ')
        if len(sen) > length:
            length = len(sen)
        sentence.append(sen)    
    fin.close()
        
    return sentence, label, length

def input_data(vec_file, train_file, test_size):
    parameters.get_vector(vec_file)
    sen,tag,length = load_data(train_file)
    X_train, X_test, y_train, y_test = train_test_split(sen, tag , test_size=test_size)
    train_shape = (len(X_train), length, 300)
    test_shape = (len(X_test), length, 300)
    train_data = MyDataset(X_train, y_train, train_shape)
    test_data = MyDataset(X_test, y_test, test_shape)

    train_loader = DataLoader(train_data, shuffle=True, batch_size=parameters.Batch_size, pin_memory=True)
    test_loader = DataLoader(test_data, shuffle=True, batch_size=parameters.Batch_size, pin_memory=True)
    
    return train_loader,test_loader