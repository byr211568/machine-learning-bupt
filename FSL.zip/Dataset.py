# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 20:09:09 2021

@author: Glaci
"""
import torch
import parameters
from torch.utils.data import Dataset

class MyDataset(Dataset):
    def __init__(self, sentence, tags, shape):        
        temp_tensor=torch.zeros(size=shape)
        for i in range(shape[0]):            
            for j in range(len(sentence[i])):
                if sentence[i][j] in parameters.word_to_vec:                    
                    temp=torch.tensor(parameters.word_to_vec[sentence[i][j]])                    
                    temp_tensor[i,j] = temp
        self.sentence = temp_tensor
        temp_tensor=torch.zeros(size=(shape[0],1), dtype=int)
        for i in range(shape[0]):
            temp_tensor[i]=parameters.tag_to_id[tags[i]]
        self.tags = temp_tensor

    def __len__(self):
        return len(self.tags)

    def __getitem__(self, idx):        
        sen=self.sentence[idx]
        tag=self.tags[idx]
        return sen, tag