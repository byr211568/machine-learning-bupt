# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 19:48:53 2021

@author: Glaci
"""
import torch
import torch.nn as nn
from Model_part import Encoder, Induction, Relation
import parameters

class FewShotModel(nn.Module):
    def __init__(self, C, S, vocab_size, embed_size, hidden_size, d_a,
                 iterations, outsize, weights=None):
        super(FewShotModel, self).__init__()
        self.encoder = Encoder(C, S, vocab_size, embed_size, hidden_size, d_a, weights)
        self.induction = Induction(C, S, 2 * hidden_size, iterations)
        self.relation = Relation(C, 2 * hidden_size, outsize)
        

    def forward(self, x):
        support_encoder, query_encoder = self.encoder(x)  #(k*c, 2*hidden_size)
        class_vector = self.induction(support_encoder)
        probs = self.relation(class_vector, query_encoder)
        return probs
    
    
    def criterion(self, predict,target):
        target = target[parameters.Qnum:]
        pred = torch.argmax(predict, dim=1)
        acc = 0
        for i in range(len(target)):
            if target[i][0] == pred[i]:
                acc += 1        
        acc = acc/target.shape[0]        
        target_onehot = torch.zeros_like(predict)
        target_onehot = target_onehot.scatter(1, target.reshape(-1, 1), 1)        
        loss = torch.mean((predict - target_onehot) ** 2)
        
        return loss, acc
    