# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 10:46:00 2021

@author: Administrator
"""
import torch
import torch.nn as nn
from torch import optim
from torch.nn import functional as F

import numpy as np
import os

from Model import FewShotModel
from input_data import input_data
import parameters

def train(epoch, batch):
    data, target = batch
    data = data.to(device)
    target = target.to(device)
    optimizer.zero_grad()
    predict = model(data)
    loss, acc = model.criterion(predict, target)
    loss.backward()
    optimizer.step()
    if epoch % 5 == 0:
        print('Batch:{}, Loss={}'.format(epoch, loss.item()))
    

def evaluate(data_loader):
    model.eval()
    correct = 0.
    count = 0.
    for data, target in data_loader:
        if data.shape[0]!=32:
            break
        data = data.to(device)
        target = target.to(device)
        
        predict = model(data)
        _, acc = model.criterion(predict, target)
        amount = len(target) - parameters.Qnum
        correct += acc * amount
        count += amount
    acc = correct/count    
    return acc

if __name__ == "__main__":
    vec_file = r'.\wiki.en.vec'
    train_file = r'.\train_shuffle.txt'
    model_path = r'.\model_1.pth'
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    #加载数据
    train_loader, test_loader = input_data(vec_file, train_file, parameters.test_size)
    weights = np.array([])
    
    #构建模型
    model = FewShotModel(C=5,
                            S=2,
                            vocab_size=len(parameters.word_to_id),
                            embed_size=300,
                            hidden_size=parameters.Hidden_dim,
                            d_a=parameters.Da_size,
                            iterations=parameters.Iteration,
                            outsize=5,
                            weights=weights).to(device)
    print('Detailed information of Model:\n', model)
    optimizer = optim.Adam(model.parameters(), lr=parameters.Learning_rate)
    
    #model = torch.load(model_path)
    #训练模型并评测
    acc_max = 0.0
    for e in range(parameters.Epochs):
        print('\nEpoch {}:'.format(e))
        model.train()
        j = 0
        for batch in train_loader:
            train(j, batch)   
            j += 1
            
        print('Predicting...')
        acc = evaluate(test_loader)
        print('Epoch {}, Accuacy={}'.format(e, acc))
        if acc > acc_max:
            print('Saving model...')
            torch.save(model, model_path)
            acc_max = acc
    print('Max_accuracy=', acc_max)